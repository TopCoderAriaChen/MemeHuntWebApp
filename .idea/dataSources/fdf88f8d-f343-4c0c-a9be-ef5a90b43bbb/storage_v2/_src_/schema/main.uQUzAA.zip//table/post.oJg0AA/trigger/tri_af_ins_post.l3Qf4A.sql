CREATE TRIGGER "tri_af_ins_post"
AFTER INSERT
ON "post"
BEGIN
  -- Type the SQL Here.
	update post set id=(select max(id)+1 from post) where id =0;
END;

