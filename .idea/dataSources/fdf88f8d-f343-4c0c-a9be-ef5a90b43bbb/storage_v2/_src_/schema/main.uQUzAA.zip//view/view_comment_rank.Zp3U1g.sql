CREATE VIEW "view_comment_rank" AS select 
 id,
 username,
 (select count(distinct p0.id) from post p0 where p0.author_id=a.id)  number_of_post
 ,number_of_comment,credits,level
 from 
 (
 SELECT
	u.id,
	u.username,
	--count(distinct p.id ) number_of_post,	
	count(distinct c.id ) number_of_comment,
	sum( IFNULL(p.credit * c.accept/5,0) ) credits ,
	u.level
FROM "user" u left join "comment" c on u.id=c.author_id
	  left join post p ON p.id=c.post_id
GROUP BY
	u.id,u.username 
ORDER BY
	credits DESC
) a
where 1=1;

