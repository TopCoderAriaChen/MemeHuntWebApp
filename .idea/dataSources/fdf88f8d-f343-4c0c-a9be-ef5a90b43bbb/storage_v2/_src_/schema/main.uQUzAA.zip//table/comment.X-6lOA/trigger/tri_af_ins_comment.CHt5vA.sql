CREATE TRIGGER "tri_af_ins_comment"
AFTER INSERT
ON "comment"
BEGIN
  -- Type the SQL Here.
	update comment
	 set id=(select max(id)+1 from comment) where id =0;
END;

