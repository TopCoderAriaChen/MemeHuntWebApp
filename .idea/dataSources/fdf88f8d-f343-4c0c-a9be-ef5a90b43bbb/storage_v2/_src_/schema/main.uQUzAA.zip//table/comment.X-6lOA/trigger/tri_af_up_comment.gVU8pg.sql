CREATE TRIGGER "tri_af_up_comment"
AFTER UPDATE OF "accept"
ON "comment"
BEGIN
  -- Type the SQL Here.
	update user 
	 set credit=(
	  SELECT round(sum(1.0*p.credit*c.accept/5),0) credits
			FROM "comment" c left join post p on c.post_id=p.id
			where c.author_id=NEW.author_id)
	 where id =OLD.author_id
	 ;
	
	update user 
	 set level=1+round(credit/500,0)
		 where id =OLD.author_id
	;
END;

