CREATE VIEW "view_active_posts" AS select `p`.`id` AS `id`,`p`.`title` AS `title`,`p`.`create_time` AS `create_time`,`b`.`name` AS `board_name` from (`post` `p` join `board` `b` on((`p`.`board_id` = `b`.`id`))) where (`p`.`is_active` = 1);

